# COSMOSYY — Procedural 3D prototype pack

26 object entries, each with an individual GLB and a JSON component manifest, plus a browser-based Three.js viewer with mouse orbit, auto-rotation, and an explode slider.

## IMPORTANT ACCURACY LIMITATIONS
- These are **illustrative procedural blockouts** made from basic meshes, NOT exact NASA spacecraft geometry.
- Dimensions and component locations are invented illustrative units and MUST NOT be used as real measurements.
- Objects sharing an archetype currently share the same simplified geometry; differences between historical missions are NOT reconstructed.
- No hidden parts can be recovered accurately from a single screenshot.
- A 3D GLB is editable and viewable, but this is NOT a NASA CAD dataset, photogrammetry, or high-resolution textured scan.
- Component names are approximate modeling labels; actual hardware varies.
- The reference screenshot is included for UI direction only.

## Use
1. Extract ZIP.
2. Run `python -m http.server 8000` inside `website` parent folder? Instead run from the ZIP root: `python -m http.server 8000`.
3. Open `http://localhost:8000/website/`.
4. Choose spacecraft, orbit with mouse, toggle Revolve, drag Explode slider.

## For a production-quality site
Replace each GLB with NASA verified geometry or manually modeled assets, preserving per-part mesh names; verify source licensing, exact dimensions and part hierarchy. Improve the viewer with realistic PBR textures, transparent hologram shader, part labels, and a carefully authored assembly timeline.

## Reference sources to verify individually
https://nssdc.gsfc.nasa.gov/
https://science.nasa.gov/
https://nasa3d.arc.nasa.gov/

## Historical note
Apollo 11 EASEP consisted of a passive seismometer and a separate laser retroreflector; do not conflate them into a single mechanism.
